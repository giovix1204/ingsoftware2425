package org.command;

import org.LibroGUI;
import org.LibroService;

public class CaricalibriCommand implements Command ,Cloneable {
    private final LibroGUI libroGUI;
    private final LibroService libroService;

    public CaricalibriCommand(LibroGUI libroGUI, LibroService libroService) {
        this.libroGUI = libroGUI;
        this.libroService = libroService;
    }//CaricalibriCommand

    @Override
    public boolean fatto(){
        LibroGUI.aggiornaListaLibri(libroService.getTuttiLibri());
        return true;
    }//fatto

    @Override
    public boolean nonfatto(){
        return false;
    }//nonfatto

    @Override
    public CaricalibriCommand clone() {
        try {
            return (CaricalibriCommand) super.clone();
        } catch (CloneNotSupportedException e) {
            throw new AssertionError("Clone not supported", e);
        }
    }


}//CaricalibriCommand
