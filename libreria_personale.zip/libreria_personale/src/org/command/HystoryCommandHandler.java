package org.command;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

public class HystoryCommandHandler implements CommandHandler, ActionListener {

    private int maxHistoryLength = 100;

    private final LinkedList<Command> history = new LinkedList<>();

    private final LinkedList<Command> redoList = new LinkedList<>();

    public HystoryCommandHandler() {
        this(100);
    }

    public HystoryCommandHandler(int maxHistoryLength) {

        if (maxHistoryLength < 0)
            throw new IllegalArgumentException();
        this.maxHistoryLength = maxHistoryLength;
    }//HistoryCommandHandler

    public void handle(Command cmd) {

        if (cmd.fatto()) {
            // restituisce true: può essere annullato
            addToHistory(cmd);
        } else {
            // restituisce false: non può essere annullato
            history.clear();
        }
        if (redoList.size() > 0)
            redoList.clear();
    }//handle

    public void redo() {
        if (redoList.size() > 0) {
            Command redoCmd = redoList.removeFirst();
            redoCmd.fatto();
            history.addFirst(redoCmd);

        }//if
    }//redo

    public void undo() {
        if (history.size() > 0) {
            Command undoCmd = history.removeFirst();
            undoCmd.nonfatto();
            redoList.addFirst(undoCmd);
        }//if
    }//undo

    private void addToHistory(Command cmd) {
        history.addFirst(cmd);
        if (history.size() > maxHistoryLength) {
            history.removeLast();
        }//if

    }//addToHistory

    @Override
    public void actionPerformed(ActionEvent e) {
        String comando = e.getActionCommand();
        switch (comando) {
            case "<-":
                undo();
                break;
            case "->":
                redo();
                break;
        }//switch
    }//actionPerformed
}//HystoryCommandHandler
