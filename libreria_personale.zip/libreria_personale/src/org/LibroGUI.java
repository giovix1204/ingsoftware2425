package org;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
public class LibroGUI extends JFrame{
        private static LibroService libroService=new LibroService();
        private JTextArea areaTesto;

        public LibroGUI() {


            setTitle("Gestione Libreria personale");
            setSize(800, 400);
            setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            setLayout(new BorderLayout());

            areaTesto = new JTextArea();
            areaTesto.setEditable(false);
            add(new JScrollPane(areaTesto), BorderLayout.CENTER);

            JPanel panelBottoni = new JPanel();
            panelBottoni.setLayout(new GridLayout(2, 2));

            JButton btnVisualizza = new JButton("Visualizza Libri");
            JButton btnAggiungi = new JButton("Aggiungi Libro");
            JButton btnModifica = new JButton("Modifica Libro");
            JButton btnElimina = new JButton("Elimina Libro");
            JButton btnCerca = new JButton("Cerca Libro per Autore");
            JButton btnCercaGenere=new JButton("Cerca libro per Genere");
            JButton btnCercaPerTitolo=new JButton("Cerca Libro per Titolo");
            JButton btnVisualizzaOrdperTitolo=new JButton("Visualizza Libri ordinati per Titolo");

            panelBottoni.add(btnVisualizza);
            panelBottoni.add(btnAggiungi);
            panelBottoni.add(btnModifica);
            panelBottoni.add(btnElimina);
            panelBottoni.add(btnCerca);
            panelBottoni.add(btnCercaGenere);
            panelBottoni.add(btnCercaPerTitolo);
            panelBottoni.add(btnVisualizzaOrdperTitolo);

            add(panelBottoni, BorderLayout.SOUTH);

            btnVisualizza.addActionListener(e -> visualizzaLibri());
            btnAggiungi.addActionListener(e -> aggiungiLibro());
            btnModifica.addActionListener(e -> modificaLibro());
            btnElimina.addActionListener(e -> eliminaLibro());
            btnCerca.addActionListener(e->cercaLibroPerAutore());
            btnCercaGenere.addActionListener(e -> cercaLibroPerGenere());
            btnCercaPerTitolo.addActionListener(e -> cercaLibroPerTitolo());
            btnVisualizzaOrdperTitolo.addActionListener(e -> visualizzaOrdinatiperTitolo());
        }//libroGUI

        public void visualizzaLibri() {
            List<Libro> libri = libroService.getTuttiLibri();
            StringBuilder sb = new StringBuilder("Libri disponibili:\n");
            for (Libro libro : libri) {
                sb.append(libro.getTitolo()).append(" - ").append(libro.getAutore()).append(" - ")
                        .append(libro.getGenere()).append(" - ").append(libro.getValutazione()).append(" - ")
                        .append(libro.getCodiceISBN()).append(" - ").append(libro.getStato_lettura()).append(" - \n");
            }
            areaTesto.setText(sb.toString());
        }//visualizzaLibri

        private void aggiungiLibro() {
            String titolo="";
            while (true) {
                 titolo = JOptionPane.showInputDialog("Inserisci il titolo del libro:");
                if (titolo == null) {
                    //l'utente ha premuto annulla
                    JOptionPane.showMessageDialog(null, "Inserimento annullato dall'utente.");
                    break;
                }
                if (titolo.trim().isEmpty()) {
                    // Il titolo è vuoto o solo spazi
                    JOptionPane.showMessageDialog(null, "Il titolo non può essere vuoto. Riprova.");
                } else {
                    // Titolo valido
                    JOptionPane.showMessageDialog(null, "Titolo inserito: " + titolo);
                    break;
                }
            }//while
            String autore ="";
            while (true) {
                autore = JOptionPane.showInputDialog("Inserisci l'autore del libro:");
                if (autore == null) {
                    JOptionPane.showMessageDialog(this, "autore nullo!");
                }
                if (autore.trim().isEmpty()) {
                    JOptionPane.showMessageDialog(null, "L'autore non può essere vuoto. Riprova.");
                } else {
                    JOptionPane.showMessageDialog(null, "Autore inserito: " + autore);
                    break;
                }
            }//while
            String genere = "";
            while (true) {
                genere = JOptionPane.showInputDialog("Inserisci il genere:");
                if (genere == null) {
                    JOptionPane.showMessageDialog(this, "genere nullo!");
                }
                if (genere.trim().isEmpty()) {
                    JOptionPane.showMessageDialog(null, "Il genere non può essere vuoto. Riprova.");
                } else {
                    JOptionPane.showMessageDialog(null, "Genere inserito: " + genere);
                    break;
                }
            }//while
            String valutazione ="";
            while(true) {
                valutazione = JOptionPane.showInputDialog("Inserisci la valutazione del libro(da 1 a 5 stelle):");
                if (valutazione == null) {
                    JOptionPane.showMessageDialog(this, "valutazione nulla!");
                }
                if (valutazione.trim().isEmpty()) {
                    JOptionPane.showMessageDialog(null, "La valutazione non può essere vuota. Riprova.");
                } else {
                    JOptionPane.showMessageDialog(null, "Valutazione inserita: " + valutazione);
                    break;
                }
            }//while
            String stato_lettura = "";
            while(true) {
                stato_lettura = JOptionPane.showInputDialog("Inserisci lo stato di lettura del libro(letto/da leggere/in lettura):");
                if (stato_lettura == null) {
                    JOptionPane.showMessageDialog(this, "stato di lettura nulla!");
                }
                if (stato_lettura.trim().isEmpty()) {
                    JOptionPane.showMessageDialog(null, "Lo stato di lettura non può essere vuoto. Riprova.");
                } else {
                    JOptionPane.showMessageDialog(null, "Stato di lettura inserito: " + stato_lettura);
                    break;
                }
            }//while
            String codice_ISBN = "";
            while(true){
                codice_ISBN=JOptionPane.showInputDialog("Inserisci il codice ISBN del libro:");
                if (codice_ISBN == null){
                    JOptionPane.showMessageDialog(this,"codice ISBN nullo!");
                }
                if(codice_ISBN.trim().isEmpty()){
                    JOptionPane.showMessageDialog(null, "Il codice ISBN non può essere vuoto. Riprova.");
                }else{
                    JOptionPane.showMessageDialog(null, "Codice ISBN inserito: " + codice_ISBN);
                    break;
                }
            }
            if(titolo!=null && autore!=null && genere!=null && valutazione!=null && stato_lettura!=null && codice_ISBN!=null){
                Libro nuovoLibro = new Libro(titolo,autore,codice_ISBN,genere,valutazione,stato_lettura);
                libroService.aggiungiLibro(nuovoLibro);
                JOptionPane.showMessageDialog(this, "Libro aggiunto con successo!");
            }//if
            visualizzaLibri();
        }//aggiungiLibro

        private void modificaLibro() {
            String titolo = JOptionPane.showInputDialog("Inserisci il titolo del libro da modificare:");
            Libro libro = libroService.cercaLibro(titolo);

            if (libro != null) {
                String NuovoTitolo=JOptionPane.showInputDialog("Inserisci il nuovo titolo del libro da modificare:");
                libro.setTitolo(NuovoTitolo);
                JOptionPane.showMessageDialog(this, "Titolo modificato con successo!");
                visualizzaLibri();
            } else {
                JOptionPane.showMessageDialog(this, "Libro non trovato!");
                }
        }//modificaLibro

        private void eliminaLibro() {
            String titolo = JOptionPane.showInputDialog("Inserisci il titolo del libro da eliminare:");
            libroService.eliminaLibro(titolo);
            JOptionPane.showMessageDialog(this, "Libro eliminato (se esisteva).");
            visualizzaLibri();
        }//eliminaLibro

        private void cercaLibroPerAutore() {
            String autore=JOptionPane.showInputDialog("Inserisci autore per cui visualizzare tutti i suoi libri:");
            StringBuilder sb = new StringBuilder("Libri per autore:\n");
            List<Libro>libriautore=libroService.cercaLibroPerAutore(autore);
            for(Libro libro:libriautore){
                sb.append(libro.getTitolo()).append(" - ").append(libro.getAutore()).append(" - ")
                        .append(libro.getGenere()).append(" - ").append(libro.getValutazione()).append(" - ")
                        .append(libro.getCodiceISBN()).append(" - ").append(libro.getStato_lettura()).append(" - \n");
            }//for
            areaTesto.setText(sb.toString());
        }//cercaLibroPerAutore

        private void cercaLibroPerGenere() {
        String genere=JOptionPane.showInputDialog("Inserisci il genere per cui visualizzare tutti i relativi libri");
        StringBuilder sb = new StringBuilder("Libri per genere:\n");
        List<Libro>librigenere=libroService.cercaLibroPerGenere(genere);
        for(Libro libro:librigenere){
            sb.append(libro.getTitolo()).append(" - ").append(libro.getAutore()).append(" - ")
                    .append(libro.getGenere()).append(" - ").append(libro.getValutazione()).append(" - ")
                    .append(libro.getCodiceISBN()).append(" - ").append(libro.getStato_lettura()).append(" - \n");
        }//for
            areaTesto.setText(sb.toString());
        }//CercaLibroPerGenere

        private void cercaLibroPerTitolo(){
            String Titolo=JOptionPane.showInputDialog("Inserisci il titolo");
            StringBuilder sb = new StringBuilder("Libri per titolo:\n");
            List<Libro>libriperTitolo=libroService.cercaLibroPerTitolo(Titolo);
            for(Libro libro:libriperTitolo){
                sb.append(libro.getTitolo()).append(" - ").append(libro.getAutore()).append(" - ")
                        .append(libro.getGenere()).append(" - ").append(libro.getValutazione()).append(" - ")
                        .append(libro.getCodiceISBN()).append(" - ").append(libro.getStato_lettura()).append(" - \n");
            }//for
            areaTesto.setText(sb.toString());
        }//cercaLibroPerTitolo

        private void visualizzaOrdinatiperTitolo(){
            StringBuilder sb = new StringBuilder("Ordinati per titolo:\n");
            List<Libro>libriOrdinati=libroService.getTuttiLibri();
            libriOrdinati.sort(Comparator.comparing(Libro::getTitolo));
            for(Libro libro:libriOrdinati){
                sb.append(libro.getTitolo()).append(" - ").append(libro.getAutore()).append(" - ")
                        .append(libro.getGenere()).append(" - ").append(libro.getValutazione()).append(" - ")
                        .append(libro.getCodiceISBN()).append(" - ").append(libro.getStato_lettura()).append(" - \n");
            }//for
            areaTesto.setText(sb.toString());
        }//visualizzaOrdinatiperTitolo

        public static void aggiornaListaLibri(List<Libro> libri){
            libroService.pulizia();//pulisce gli elementi
            for(Libro l:libri){
                libroService.aggiungiLibro(l);
            }//for
            libroService.mostraTuttiLibri();
        }//aggiornaListaLibri


        public static void main(String[] args) {
            SwingUtilities.invokeLater(() -> {
                LibroGUI gui = new LibroGUI();
                gui.setVisible(true);
            });
        }
    }
