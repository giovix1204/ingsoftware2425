package org;


public class Libro {
    private static Libro instance;
    public String titolo;
    public String autore;
    public String codiceISBN;
    public String genere;
    public String valutazione;
    public String stato_lettura;

    private Libro() {}

    public static Libro getInstance(){
        if(instance==null){
            instance=new Libro();
        }
        return Libro.instance;
    }//getInstance

    public Libro(String titolo,String autore,String codiceISBN,String genere,String valutazione,String stato_lettura) {
        this.titolo = titolo;
        this.autore = autore;
        this.codiceISBN = codiceISBN;
        this.genere = genere;
        this.valutazione = valutazione;
        this.stato_lettura = stato_lettura;
    }//Libro

    public String getTitolo() {
        return titolo;
    }

    public void setTitolo(String titolo) {
        this.titolo = titolo;
    }

    public String getAutore() {
        return autore;
    }

    public void setAutore(String autore) {
        this.autore = autore;
    }

    public String getCodiceISBN() {
        return codiceISBN;
    }

    public void setCodiceISBN(String codiceISBN) {
        this.codiceISBN = codiceISBN;
    }

    public String getGenere() {
        return genere;
    }

    public void setGenere(String genere) {
        this.genere = genere;
    }

    public String getValutazione() {
        return valutazione;
    }

    public void setValutazione(String valutazione) {
        this.valutazione = valutazione;
    }

    public String getStato_lettura() {
        return stato_lettura;
    }

    public void setStato_lettura(String stato_lettura) {
        this.stato_lettura = stato_lettura;
    }
    public void mostraDettagli(){
        System.out.println("Dettagli del libro " + titolo);
        System.out.println("Autore: " + autore);
        System.out.println("Codice ISBN: " + codiceISBN);
        System.out.println("Genere: " + genere);
    }//mostraDettagli
}//Libro
