package org;
import java.sql.*;
import java.util.Scanner;
import com.mysql.jdbc.*;
import com.mysql.cj.*;

public class Main {
    private static Connection connection;
    private static String urlDb="jdbc:mysql://localhost:3306/giovanni?useSSL=false&serverTimezone=Europe/Rome";
    public static String username="root";
    public static String password="Giovanni1234";

    private static Connection getConnessione(String urlDb,String username,String password)throws SQLException{
        try{
            connection = DriverManager.getConnection(urlDb,username,password);
        }catch(SQLException e){
            e.printStackTrace();
        }
        return connection;
    }//getConnessione
    public static void main(String[] args) throws SQLException {
        Scanner scanner = new Scanner(System.in);
        LibroService libroService=new LibroService();
        System.out.println("Benvenuto nel sistema di gestione libreria personale!");

        while (true) {
            System.out.println("\nScegli un'operazione:");
            System.out.println("1. Aggiungi un libro");
            System.out.println("2. Visualizza tutti i libri");
            System.out.println("3. Modifica il titolo di un libro");
            System.out.println("4. Elimina un libro");
            System.out.println("5. Inserisci l'autore per cui cercare tutti i suoi libri");
            System.out.println("6. Torna al menu principale");

            int scelta = scanner.nextInt();
            scanner.nextLine();

            switch (scelta) {
                case 1:
                    try {
                        System.out.println("Inserisci il titolo del libro:");
                        String titolo = scanner.nextLine();
                        System.out.println("Inserisci l'autore del libro:");
                        String autore = scanner.nextLine();
                        System.out.println("Inserisci il genere del libro:");
                        String genere = scanner.nextLine();
                        System.out.println("Inserisci lo stato di lettura del libro:");
                        String stato_lettura = scanner.nextLine();
                        System.out.println("Inserisci il codice ISBN del libro");
                        String codiceISBN = scanner.nextLine();
                        System.out.println("Inserisci la valutazione del libro(da 1 a stelle)");
                        String valutazione = scanner.nextLine();
                        libroService.aggiungiLibro(new Libro(titolo, autore, codiceISBN, genere, stato_lettura, valutazione));
                        Connection c=getConnessione(urlDb,username,password);
                        String query="INSERT INTO libreria(titolo,autore,genere,valutazione,stato_lettura,codice_ISBN) VALUES(?,?,?,?,?,?)";
                        PreparedStatement pst=c.prepareStatement(query);
                        pst.setString(1,titolo);
                        pst.setString(2,autore);
                        pst.setString(3,genere);
                        pst.setString(4,valutazione);
                        pst.setString(5,stato_lettura);
                        pst.setString(6,codiceISBN);
                        int i=pst.executeUpdate();
                        while(i<0){
                            System.out.println(i);
                        }
                        pst.close();
                        connection.close();
                    }catch(SQLException e){
                        e.getSQLState();
                    }
                    break;
                case 2:
                    //libroService.mostraTuttiLibri();
                    try{
                        Connection c=getConnessione(urlDb,username,password);
                        String query="SELECT * FROM libreria";
                        PreparedStatement pst=c.prepareStatement(query);
                        ResultSet rs=pst.executeQuery();
                        while(rs.next()){
                            System.out.println("Dettagli del Libro: "+rs.getString("titolo"));
                            System.out.println("Autore: "+rs.getString("autore"));
                            System.out.println("Genere: "+rs.getString("genere"));
                            System.out.println("Stato lettura: "+rs.getString("stato_lettura"));
                            System.out.println("Codice_ISBN: "+rs.getString("codice_ISBN"));
                            System.out.println("Valutazione: "+rs.getString("valutazione"));
                        }//while
                        pst.close();
                        connection.close();
                    }catch (SQLException e){
                        e.getSQLState();
                    }
                    break;
                case 3:
                    System.out.println("Inserisci il titolo del libro da modificare:");
                    String titoloModifica = scanner.nextLine();
                    if(titoloModifica!=null) {
                        System.out.println("Inserisci nuovo titolo:");
                        String nuovoTitolo1 = scanner.nextLine();
                        Connection c = getConnessione(urlDb, username, password);
                        String querym = "UPDATE libreria SET titolo = '" + nuovoTitolo1 + "' WHERE titolo = '" + titoloModifica + "'";
                        ;
                        PreparedStatement pst = c.prepareStatement(querym);
                        pst.executeUpdate();
                        System.out.println("Titolo libro aggiornato con successo!");
                        pst.close();
                        c.close();
                    }else{
                        System.out.println("titolo nullo");
                    }
                    /* CODICE PER MODIFICARE IL TITOLO DEL LIBRO DA LIBROSERVICE
                    Libro titoloLibro = libroService.cercaLibro(titoloModifica);
                    if (titoloLibro != null) {
                        System.out.println("Inserisci nuovo titolo:");
                        String nuovoTitolo = scanner.nextLine();
                        titoloLibro.setTitolo(nuovoTitolo);
                        System.out.println("Titolo libro aggiornato con successo!");
                    }
                    else {
                        System.out.println("Libro non trovato.");
                    }
                    */
                    break;
                case 4:
                    System.out.println("Inserisci titolo del libro da eliminare:");
                    String titoloElimina = scanner.nextLine();
                    Connection c = getConnessione(urlDb, username, password);
                    String queryd="DELETE FROM libreria WHERE titolo='"+titoloElimina+"'";
                    Statement st=c.createStatement();
                    st.executeUpdate(queryd);
                    st.close();
                    c.close();
                    System.out.println("Titolo eliminato con successo!");
                    //CODICE PER ELIMINARE UN LIBRO DA LIBROSERVICE
                    //libroService.eliminaLibro(titoloElimina);
                    break;
                case 5:
                    System.out.println("Inserisci l'autore per cui cercare tutti i suoi libri:");
                    String autorec=scanner.nextLine();
                    Connection cc=getConnessione(urlDb,username,password);
                    String queryautore="SELECT * FROM libreria WHERE autore='"+autorec+"'";
                    PreparedStatement pst=cc.prepareStatement(queryautore);
                    ResultSet rs=pst.executeQuery();
                    while(rs.next()){
                        System.out.println("Autore: "+rs.getString("autore"));
                        System.out.println("Titolo: "+rs.getString("titolo"));
                        System.out.println("Genere: "+rs.getString("genere"));
                        System.out.println("Stato lettura: "+rs.getString("stato_lettura"));
                        System.out.println("Codice_ISBN: "+rs.getString("codice_ISBN"));
                        System.out.println("Valutazione: "+rs.getString("valutazione"));
                    }//while
                    //CODICE PER CERCARE I LIBRI PER AUTORE DA LIBROSERVICE
                    //System.out.println(libroService.cercaLibroPerAutore(autorec));
                    cc.close();
                    break;
                case 6:
                    return;
                default:
                    System.out.println("Scelta non valida. Riprova.");
            }
        }
    }
}
