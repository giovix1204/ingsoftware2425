package org;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Scanner;
public class Controller_libro {
    private LibroService libroService=new LibroService();
    private Connection connection;
    private String urlDb="jdbc:mysql://localhost:3306/giovanni";
    public static String username="root";
    public static String password="Giovanni1234";

    public void avvia() throws SQLException {
        Scanner sc=new Scanner(System.in);
        connection= DriverManager.getConnection(urlDb,username,password);
        while(true){
            System.out.println("1. AggiungiLibro\n2. VisualizzaLibri\n3. CercaLibroPerTitolo\n4. EliminaLibro\n5. CercaLibroPerAutore\n6. CercaLibroPerGenere\n7. CercaLibroPerStato\n8. CercaLibroPerValutazione\n9.VisualizzaLibriPerAutore\n10. VisualizzaLibriOrdinatiPerTitolo \n11. VisualizzaLibriOrdinatiperAutore \n12. ModificaTitoloLibro \n13 ModificaAutoreLibro \n14. Esci\n15.");
            int scelta=sc.nextInt();
            switch(scelta){
                case 1:
                    System.out.println("Inserisci il titolo del libro");
                    String titolo=sc.nextLine();
                    System.out.println("Inserisci il genere del libro");
                    String genere=sc.nextLine();
                    System.out.println("Inserisci lo stato di lettura del libro");
                    String stato=sc.nextLine();
                    System.out.println("Inserisci l'autore del libro");
                    String autore=sc.nextLine();
                    System.out.println("Inserisci il codice ISBN del libro");
                    String codiceISBN=sc.nextLine();
                    System.out.println("Inserisci la valutazione del libro(da 1 a 5 stelle)");
                    String valutazione=sc.nextLine();
                    libroService.aggiungiLibro(new Libro(titolo,autore,codiceISBN,genere,stato,valutazione));
                    String query="INSERT INTO libreria(titolo,autore,genere,valutazione,stato_lettura,codice_ISBN) VALUES(?,?,?,?,?,?)";
                    PreparedStatement pst=connection.prepareStatement(query);
                    pst.setString(1,titolo);
                    pst.setString(2,autore);
                    pst.setString(3,genere);
                    pst.setString(4,valutazione);
                    pst.setString(5,stato);
                    pst.setString(6,codiceISBN);
                    int i=pst.executeUpdate();
                    while(i<0){
                        System.out.println(i);
                    }
                    pst.close();
                    connection.close();
                    break;
                case 2:
                    libroService.mostraTuttiLibri();
                    break;
                case 3:
                    System.out.println("Inserisci il titolo del libro da cercare:");
                    String ricerca=sc.nextLine();
                    Libro libro=libroService.cercaLibro(ricerca);
                    if (libro != null) {
                        libro.mostraDettagli();
                    } else {
                        System.out.println("Libro non trovato.");
                    }
                    break;
                case 4:
                    System.out.println("Inserisci il titolo del libro da eliminare:");
                    String titoloEliminare = sc.nextLine();
                    libroService.eliminaLibro(titoloEliminare);
                    break;
                case 5:
                    System.out.println("Inserisci l'autore del libro da cercare:");
                    String autoredaCercare = sc.nextLine();
                    List<Libro>libri=libroService.cercaLibroPerAutore(autoredaCercare);
                    for(Libro l:libri){
                        l.mostraDettagli();
                    }//for
                    break;
                case 6:
                    System.out.println("Inserisci il genere del libro da cercare:");
                    String genereCercare=sc.nextLine();
                    List<Libro>libriGenere=libroService.cercaLibroPerGenere(genereCercare);
                    for(Libro l:libriGenere){
                        l.mostraDettagli();
                    }//for
                    break;
                case 7:
                    System.out.println("Inserisci lo stato di lettura del libro da cercare:");
                    String statoLettura=sc.nextLine();
                    List<Libro>libriStato=libroService.cercaLibroPerStato(statoLettura);
                    for(Libro l:libriStato){
                        l.mostraDettagli();
                    }//for
                    break;
                case 8:
                    System.out.println("Inserisci la valutazione del libro da cercare(da 1 a 5 stelle):");
                    String valutazioneL=sc.nextLine();
                    List<Libro>librivalutazione=libroService.cercaLibroPerValutazione(valutazioneL);
                    for(Libro l:librivalutazione){
                        l.mostraDettagli();
                    }//for
                    break;
                case 9:
                    System.out.println("Inserisci l'autore per cui visualizzare tutti i libri da cercare:");
                    String autoreC=sc.nextLine();
                    List<Libro>libriAutore=libroService.cercaLibroPerAutore(autoreC);
                    for(Libro l:libriAutore){
                        l.mostraDettagli();
                    }//for
                    break;
                case 10:
                    System.out.println("Visualizzazione di tutti i libri ordinati per titolo:");
                    List<Libro>librititolo=libroService.getTuttiLibri();
                    librititolo.sort(Comparator.comparing(Libro::getTitolo));
                    for(Libro l:librititolo){
                        l.mostraDettagli();
                    }//for
                    break;
                case 11:
                    System.out.println("Visualizzazione di tutti i libri ordinati per autore:");
                    List<Libro>libriOrdAutore=libroService.getTuttiLibri();
                    libriOrdAutore.sort(Comparator.comparing(Libro::getAutore));
                    for(Libro l:libriOrdAutore){
                        l.mostraDettagli();
                    }//for
                    break;
                case 12:
                    System.out.println("Inserisci il titolo del libro da cercare per modificarne il suo titolo");
                    String titolodaModificare=sc.nextLine();
                    Libro ld=libroService.cercaLibro(titolodaModificare);
                    if(ld!=null){
                        System.out.println("Inserisci il nuovo titolo");
                        String nuovoTitolo=sc.nextLine();
                        if(nuovoTitolo!=null){
                            ld.setTitolo(nuovoTitolo);
                        }//if
                        else{
                            System.out.println("Nuovo titolo non valido");
                        }//else
                        System.out.println("Titolo modificato con successo");
                    }//if
                    else{
                        System.out.println("Titolo non trovato");
                    }//else
                    break;
                case 13:
                    System.out.println("Inserisci il titolo da cercare per modificarne il suo autore");
                    String titolodaCercare=sc.nextLine();
                    Libro l=libroService.cercaLibro(titolodaCercare);
                    if(l!=null){
                        System.out.println("Inserisci il nuovo autore");
                        String nuovoAutore=sc.nextLine();
                        if(nuovoAutore!=null){
                            l.setAutore(nuovoAutore);
                        }//if
                        else{
                            System.out.println("Nuovo autore non valido");
                        }//else
                    }else{
                        System.out.println("Titolo non trovato");
                    }//else
                    break;
                case 14:
                    System.out.println("Uscita in corso...");
                    sc.close();
                    return;
                default:
                    System.out.println("Scelta non valida. Riprova.");
            }
        }
    }//avvia
}//Controller_libro
