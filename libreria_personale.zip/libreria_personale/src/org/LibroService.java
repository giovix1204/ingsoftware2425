package org;

import java.util.ArrayList;
import java.util.List;

public class LibroService {
    private List <Libro> libri=new ArrayList<>();

    public LibroService(){}

    public void pulizia(){
        libri.clear();
    }//pulizia

    public void aggiungiLibro(Libro libro) {
            libri.add(libro);
            System.out.println("Libro aggiunto: " + libro.getTitolo());
    }//aggiungiLibro

    public List<Libro> getTuttiLibri() {
            return libri;
    }//getTuttiLibri

    public Libro cercaLibro(String titolo) {
        for (Libro libro : libri) {
            if (libro.getTitolo().equalsIgnoreCase(titolo)) {
                return libro;
            }//if
        }//for
        return null;
    }//cercaLibro

    public void eliminaLibro(String titolo) {
        Libro libroDaEliminare = cercaLibro(titolo);
        if (libroDaEliminare != null) {
            libri.remove(libroDaEliminare);
            System.out.println("Libro eliminato: " + titolo);
        } else {
            System.out.println("Libro non trovato.");
        }//else
    }//eliminaLibro

    public void mostraTuttiLibri() {
        for (Libro libro : libri) {
            libro.mostraDettagli();
        }//for
    }//mostraTuttiLibri

    public List<Libro> cercaLibroPerAutore(String autore) {
        List<Libro> risultatia = new ArrayList<>();
        for (Libro libro : libri) {
            if (libro.getAutore().equalsIgnoreCase(autore)) {
                risultatia.add(libro);
            }//if
        }//for
        return risultatia;
    }//cercaLibroPerAutore

    public List<Libro> cercaLibroPerGenere(String genere) {
        List<Libro> risultati = new ArrayList<>();
        for (Libro libro : libri) {
            if (libro.getGenere().equalsIgnoreCase(genere)) {
                risultati.add(libro);
            }//libro
        }//for
        return risultati;
    }//cercaLibroPerGenere

    public List<Libro>cercaLibroPerStato(String stato) {
        List<Libro>risultati=new ArrayList<>();
        for(Libro libro:libri){
            if(libro.getStato_lettura().equalsIgnoreCase(stato)){
                risultati.add(libro);
            }//else
        }//for
        return risultati;
    }//cercaLibroPerStato

    public List<Libro>cercaLibroPerValutazione(String valutazione) {
        List<Libro>risultati=new ArrayList<>();
        for(Libro libro:libri){
            if(libro.getValutazione().equalsIgnoreCase(valutazione)){
                risultati.add(libro);
            }//if
        }//for
        return risultati;
    }//cercaLibroPerValutazione

    public List<Libro> cercaLibroPerTitolo(String titolo) {
        List<Libro>risultati=new ArrayList<>();
        for(Libro libro:libri){
            if(libro.getTitolo().equalsIgnoreCase(titolo)){
                risultati.add(libro);
            }//if
        }//for
        return risultati;
    }//cercaLibroPerTitolo

}//LibroService
