package org.command;

public interface Command {
    boolean fatto();
    //return true può essere annullato;
    boolean nonfatto();
}//Command
