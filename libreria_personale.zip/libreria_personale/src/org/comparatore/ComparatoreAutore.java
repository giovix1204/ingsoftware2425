package org.comparatore;
import java.util.*;
import org.Libro;
public class ComparatoreAutore implements comparatoreLibri{
    @Override
    public int compare(Libro o1,Libro o2){
        String primoAutore1=o1.getAutore();
        String primoAutore2=o2.getAutore();
        return primoAutore1.compareToIgnoreCase(primoAutore2);
    }//compare
}//ComparatoreAutore
