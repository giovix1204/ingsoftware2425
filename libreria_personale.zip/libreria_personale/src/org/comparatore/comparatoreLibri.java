package org.comparatore;
import java.util.Comparator;
import org.Libro;

public interface comparatoreLibri extends Comparator<Libro>{
    default comparatoreLibri reversed(){
        return (Libro o1,Libro o2)->compare(o2,o1);
    }//comparatoreLibri
}//comparatoreLibri
