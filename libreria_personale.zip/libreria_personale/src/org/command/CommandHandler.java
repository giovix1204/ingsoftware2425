package org.command;

public interface CommandHandler {
    void handle(Command command);
}//CommandHandler
