package org.comparatore;
import org.Libro;
public class comparatoreTitolo implements comparatoreLibri{
    @Override
    public int compare(Libro o1,Libro o2){
        return o1.getTitolo().compareToIgnoreCase(o2.getTitolo());
    }//compare

}//comparatoreTitolo
