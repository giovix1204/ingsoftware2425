package org.command;
import org.*;
public class AggiungiLibroCommand implements Command,Cloneable{
    private final LibroGUI libroGUI;
    private final LibroService libroService;
    private Libro libro;

    public AggiungiLibroCommand(LibroGUI libroGUI, LibroService libroService, Libro libro) {
        this.libroGUI = libroGUI;
        this.libroService = libroService;
        this.libro = libro;
    }//AggiungiLibroCommand

    public AggiungiLibroCommand(LibroGUI libroGUI,LibroService libroService) {
        this.libroGUI = libroGUI;
        this.libroService = libroService;
    }//AggiungiLibroCommand

    public void setLibro(Libro libro) {
        this.libro = libro;
    }//setLibro

    @Override
    public boolean fatto() {
        libroService.aggiungiLibro(libro);
        new CaricalibriCommand(libroGUI,libroService).fatto();
        return true;
    }//fatto

    @Override
    public boolean nonfatto() {
        libroService.eliminaLibro(libro.getTitolo());
        new CaricalibriCommand(libroGUI,libroService).fatto();
        return true;
    }//nonfatto
    @Override
    public AggiungiLibroCommand clone() {
        try {
            return (AggiungiLibroCommand) super.clone();
        } catch (CloneNotSupportedException e) {
            throw new AssertionError("Clone not supported", e);
        }
    }//clone
}//AggiungiLibroCommand
