package TEST;

import org.Libro;
import org.comparatore.*;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Test;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;


@DisplayName("Test per i Comparatori")
public class ComparatoriTest {

    @Nested
    @DisplayName("Test ComparatoreTitolo")
    class ComparatoreTitoloTest {

        @Test
        @DisplayName("Ordinamento per titolo")
        void testOrdinamentoPerTitolo() {
            comparatoreTitolo comparatore = new comparatoreTitolo();

            Libro libro1 = new Libro("Bud Spencer", "Giovanni", "12356789X",
                    "AVVENTURA", "3 STELLE", "IN LETTURA");
            Libro libro2 = new Libro("Alice", "Luigi", "123456789X",
                    "FANTASY", "4 STELLE", "DA LEGGERE");

            assertTrue(comparatore.compare(libro2, libro1) < 0);
            assertTrue(comparatore.compare(libro1, libro2) > 0);
            assertEquals(0, comparatore.compare(libro1, libro2));
        }

        @Test
        @DisplayName("Ordinamento case insensitive")
        void testOrdinamentoCaseInsensitive() {
            comparatoreTitolo comparatore = new comparatoreTitolo();

            Libro libro1 = new Libro("alice", "Luigi", "123456789X",
                    "FANTASY", "3 STELLE", "LETTO");
            Libro libro2 = new Libro("ALICE", "Luigi", "123456789X",
                    "FANTASY", "4 STELLE", "DA_LEGGERE");

            assertEquals(0, comparatore.compare(libro1, libro2));
        }
    }

    @Nested
    @DisplayName("Test ComparatoreAutore")
    class ComparatoreAutoreTest {

        @Test
        @DisplayName("Ordinamento per autore alfabetico")
        void testOrdinamentoPerPrimoAutore() {
            ComparatoreAutore comparatore = new ComparatoreAutore();

            Libro libro1 = new Libro("Libro1", "Alice Autor", "123456789X",
                    "ROMANZO", "3 STELLE", "LETTO");
            Libro libro2 = new Libro("Libro2", "Bob Autor", "123456789X",
                    "ROMANZO", "4 STELLE", "DA LEGGERE");

            assertTrue(comparatore.compare(libro1, libro2) < 0); // Alice < Bob
        }

        @Nested
        @DisplayName("Test metodo reversed")
        class ReversedTest {

            @Test
            @DisplayName("Reversed inverte l'ordinamento")
            void testReversed() {
                comparatoreTitolo comparatore = new comparatoreTitolo();
                comparatoreLibri reversed = comparatore.reversed();

                Libro libro1 = new Libro("UN'ESTATE AL MARE", "Alice", "123456789X",
                        "FANTASY", "3 STELLE", "LETTO");
                Libro libro2 = new Libro("UNA VITA IN VACANZA", "Zorro", "123456789X",
                        "AVVENTURA", "4 STELLE", "DA LEGGERE");

                assertTrue(comparatore.compare(libro1, libro2) < 0);
                assertTrue(reversed.compare(libro1, libro2) > 0);
            }//testReversed
        }//ReversedTest
    }//ComparatoriTest
}//ComparatoriTest