package org.command;

import org.LibroGUI;
import org.LibroService;
import org.Libro;
public class ModificaLibroCommand implements Command,Cloneable{
    private final LibroGUI libroGUI;
    private final LibroService libroService;
    private Libro libroOriginale;
    private Libro libroNuovo;

    public ModificaLibroCommand(LibroGUI libroGUI, LibroService libroService, Libro libroOriginale,Libro libroNuovo) {
        this.libroGUI = libroGUI;
        this.libroService = libroService;
        this.libroOriginale = libroOriginale;
        this.libroNuovo=libroNuovo;
    }//ModificaLibroCommand

    public ModificaLibroCommand(LibroGUI libroGUI,LibroService libroService){
        this.libroGUI = libroGUI;
        this.libroService = libroService;
    }//ModificaLibroCommand

    public void SetLibroOriginale(Libro libroOriginale) {this.libroOriginale=libroOriginale;}
    public void SetLibroNuovo(Libro libroNuovo){this.libroNuovo=libroNuovo;}

    @Override
    public boolean fatto() {
        libroService.eliminaLibro(libroOriginale.getTitolo());
        libroService.aggiungiLibro(libroNuovo);
        new CaricalibriCommand(libroGUI,libroService).fatto();
        return true;
    }//fatto

    @Override
    public boolean nonfatto() {
        libroService.eliminaLibro(libroOriginale.getTitolo());
        libroService.aggiungiLibro(libroNuovo);
        new CaricalibriCommand(libroGUI,libroService).fatto();
        return true;
    }//nonfatto

    @Override
    public ModificaLibroCommand clone()  {
        try {
            return (ModificaLibroCommand) super.clone();
        } catch (CloneNotSupportedException e) {
            throw new AssertionError("Clone not supported", e);        }
    }//clone
}//ModificaLibroCommand
